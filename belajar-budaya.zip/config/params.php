<?php

return [
    'adminEmail' => 'admin@example.com',
    'fb_app_id' => '701116673300033',
    'fb_app_secret' => '768fc42e4ed8afb9778ad81288519272'
];
