<?php
	return
	[
		'yii\web\JqueryAsset' => [
           'js' => ['jquery.min.js'],
        ],
        'yii\bootstrap\BootstrapPluginAsset' => [
            'js' => ['js/bootstrap.min.js'],
        ],
        'yii\bootstrap\BootstrapAsset' => [
        	'css' => ['css/bootstrap.min.css'],
        ]
    ];
?>
