<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=gemastik',
    'username' => 'vincent',
    'password' => 'sebastian',
    'charset' => 'utf8',
    'enableSchemaCache' => true,
    'schemaCacheDuration' => 30,
    
];
