
<?php $this->beginPage() ?>
<?= $content ?>

<?php $this->endPage() ?>
